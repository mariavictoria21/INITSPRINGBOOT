package com.example.initspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InitspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
