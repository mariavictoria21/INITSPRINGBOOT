package com.example.initspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InitspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(InitspringbootApplication.class, args);
	}

}
